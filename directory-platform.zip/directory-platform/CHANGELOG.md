## v1.0.3- 08/17/2017

* FIX: empty ratings in review form
* FIX: responsive
* FIX: review user image
* FIX: feature listing in cart
* FIX: Order email
* FIX: My Favorites listing link 

## v1.0.2- 07/31/2017

* FIX: missing anonymous user image in review
* FIX: favorites page wrong template loading
* FIX: removed missing favicon

## v1.0.1- 07/24/2017

* IMPROVEMENT: enabled payment for featuring listing by default
* FIX: notification after user registration
* FIX: no orders found correct template loading